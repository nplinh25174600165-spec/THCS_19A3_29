def giai_pt_bac_nhat(a, b):
    if a == 0:
        return "vô số nghiệm" if b == 0 else "vô nghiệm"
    return -b / a